public class Main {
    public static void main(String[] args) {
        FormaManager formaManager = new FormaManager();

        try {
           //validas
            formaManager.addForma("Vermelho", "0,0", 10);
            formaManager.addForma("Verde", "1,1", 20);
            formaManager.addForma("Vermelho", "2,2", 15);
            formaManager.addForma("Azul", "3,3", 25);
            formaManager.addForma("Verde", "4,4", 30);

           //invalidas
            formaManager.addForma("", "5,5", 12);
            formaManager.addForma("Amarelo", "6,6", -5);

        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }


        formaManager.apresentar();
    }
}
